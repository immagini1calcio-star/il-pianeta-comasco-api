# Il Pianeta Comasco API — versione iniziale monolitica

## File da caricare su GitHub

- `api/[...route].js` — tutte le route API in un unico file.
- `package.json` — abilita i moduli JavaScript e Node 22.

## Test dopo il deploy

1. `/api/health`
2. `/api/squadre?league=ita.1`
3. `/api/como-team?league=ita.1`
4. `/api/classifica?league=ita.1`
5. `/api/partite?league=ita.1`
6. `/api/giocatori?league=ita.1`
7. `/api/indisponibili?league=ita.1`
8. `/api/scoreboard?league=ita.1`

## Importante

La API restituisce solo dati che la fonte fornisce. Alcune leghe o endpoint ESPN possono non essere disponibili o avere una struttura diversa. Non è possibile garantire che ogni campo sia valorizzato, né che ESPN copra Como Primavera, Como Women, probabili formazioni, squalifiche, xG o tutte le statistiche avanzate. Gli errori vengono esposti nel JSON per facilitare il debug.

Le fonti OneFootball, Sky Sport, Gazzetta e Tuttomercatoweb non sono ancora collegate in questo file. Sono elencate come fonti previste, non come integrazioni già funzionanti.
