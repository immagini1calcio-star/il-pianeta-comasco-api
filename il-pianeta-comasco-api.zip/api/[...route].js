const ESPN_SITE = "https://site.api.espn.com/apis/site/v2/sports/soccer";
const ESPN_V2 = "https://site.api.espn.com/apis/v2/sports/soccer";

const LEAGUES = {
  serie_a: "ita.1",
  coppa_italia: "ita.coppa_italia",
  champions_league: "uefa.champions",
  europa_league: "uefa.europa",
  conference_league: "uefa.europa.conf"
};

const TEAM_NAMES = ["como", "como 1907", "como women", "como primavera"];

function json(res, status, data) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");
  res.end(JSON.stringify(data, null, 2));
}

function clean(value) {
  return value === undefined ? null : value;
}

async function fetchJson(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { "User-Agent": "Il-Pianeta-Comasco/1.0" }
    });
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); }
    catch { throw new Error(`Risposta non JSON da ESPN (HTTP ${response.status})`); }
    if (!response.ok) {
      throw new Error(`ESPN HTTP ${response.status}: ${data?.message || response.statusText}`);
    }
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function espnUrl(league, resource, params = {}, version = "site") {
  const base = version === "v2" ? ESPN_V2 : ESPN_SITE;
  const url = new URL(`${base}/${league}/${resource}`);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
  }
  return url.toString();
}

function getEvents(data) {
  return data?.events || data?.leagues?.[0]?.events || data?.schedule || [];
}

function teamObject(team = {}) {
  return {
    id: team.id ?? team.team?.id ?? null,
    nome: team.displayName ?? team.name ?? team.team?.displayName ?? null,
    abbreviazione: team.abbreviation ?? team.team?.abbreviation ?? null,
    logo: team.logo ?? team.logos?.[0]?.href ?? team.team?.logo ?? team.team?.logos?.[0]?.href ?? null,
    paese: team.location ?? team.team?.location ?? null
  };
}

function normalizeEvent(event = {}) {
  const comp = event.competitions?.[0] || event.competition || {};
  const competitors = comp.competitors || event.competitors || [];
  const home = competitors.find(x => x.homeAway === "home") || competitors[0] || {};
  const away = competitors.find(x => x.homeAway === "away") || competitors[1] || {};
  const status = event.status || comp.status || {};
  const homeTeam = teamObject(home.team || home);
  const awayTeam = teamObject(away.team || away);
  const homeScore = home.score ?? null;
  const awayScore = away.score ?? null;
  const venue = comp.venue || event.venue || {};
  const date = event.date || comp.date || null;
  const statusType = status.type || {};
  return {
    id: event.id ?? null,
    data_ora_utc: date,
    nome: event.name ?? `${homeTeam.nome || "Casa"} - ${awayTeam.nome || "Trasferta"}`,
    competizione: event.season?.name ?? event.league?.name ?? null,
    giornata: event.week?.number ?? event.week ?? null,
    stato: statusType.description ?? statusType.detail ?? status.description ?? null,
    stato_codice: statusType.name ?? null,
    casa: { ...homeTeam, punteggio: homeScore, vincente: home.winner ?? null },
    trasferta: { ...awayTeam, punteggio: awayScore, vincente: away.winner ?? null },
    risultato: homeScore !== null && awayScore !== null ? `${homeScore}-${awayScore}` : null,
    stadio: venue.fullName ?? venue.name ?? null,
    citta_stadio: venue.address?.city ?? null,
    arbitro: comp.officials?.map(x => x.fullName || x.displayName).filter(Boolean) || [],
    link: event.links?.find(x => x.rel?.includes("summary"))?.href ?? null,
    fonte: "ESPN"
  };
}

function findComo(event) {
  const text = JSON.stringify(event).toLowerCase();
  return text.includes("como");
}

function normalizeStat(stat) {
  return {
    nome: stat.name ?? stat.abbreviation ?? stat.label ?? null,
    etichetta: stat.label ?? stat.displayName ?? null,
    valore: stat.displayValue ?? stat.value ?? null
  };
}

function normalizePlays(summary) {
  const plays = summary?.plays || summary?.keyEvents || [];
  return plays.map(p => ({
    id: p.id ?? null,
    minuto: p.clock?.displayValue ?? p.time?.displayValue ?? p.period?.number ?? null,
    tipo: p.type?.text ?? p.type?.name ?? p.text ?? null,
    descrizione: p.text ?? p.shortText ?? null,
    squadra: p.team?.displayName ?? null,
    giocatori: (p.participants || []).map(x => ({
      nome: x.athlete?.displayName ?? x.player?.displayName ?? null,
      ruolo_evento: x.type?.text ?? x.type?.name ?? null
    })),
    fonte: "ESPN"
  }));
}

function normalizeBoxscore(summary) {
  const teams = summary?.boxscore?.teams || [];
  const teamStats = teams.map(t => ({
    squadra: teamObject(t.team || {}),
    statistiche: (t.statistics || []).map(normalizeStat)
  }));
  const players = (summary?.boxscore?.players || []).map(block => ({
    squadra: teamObject(block.team || {}),
    gruppi: (block.statistics || []).map(group => ({
      categoria: group.name ?? group.type ?? null,
      etichette: group.labels || [],
      atleti: (group.athletes || []).map(a => ({
        giocatore: {
          id: a.athlete?.id ?? null,
          nome: a.athlete?.displayName ?? a.athlete?.fullName ?? null,
          foto: a.athlete?.headshot?.href ?? null,
          ruolo: a.athlete?.position?.abbreviation ?? null,
          numero: a.athlete?.jersey ?? null
        },
        statistiche: a.stats || []
      }))
    }))
  }));
  return { squadre: teamStats, giocatori: players };
}

function normalizeLineups(summary) {
  const blocks = summary?.boxscore?.players || [];
  return blocks.map(block => {
    const roster = [];
    for (const group of (block.statistics || [])) {
      for (const athlete of (group.athletes || [])) {
        const a = athlete.athlete || {};
        roster.push({
          id: a.id ?? null,
          nome: a.displayName ?? a.fullName ?? null,
          foto: a.headshot?.href ?? null,
          numero: a.jersey ?? null,
          ruolo: a.position?.displayName ?? a.position?.abbreviation ?? null,
          titolare: athlete.starter ?? null,
          statistiche: athlete.stats || []
        });
      }
    }
    return { squadra: teamObject(block.team || {}), giocatori: roster };
  });
}

async function safeFetch(url) {
  try { return { success: true, data: await fetchJson(url), error: null }; }
  catch (e) { return { success: false, data: null, error: e.message }; }
}

async function getScoreboard(league, dates) {
  const data = await fetchJson(espnUrl(league, "scoreboard", dates ? { dates } : {}));
  return getEvents(data).map(normalizeEvent);
}

async function getComoEvents(league) {
  const all = await getScoreboard(league);
  return all.filter(e => {
    const s = `${e.casa.nome || ""} ${e.trasferta.nome || ""}`.toLowerCase();
    return s.includes("como");
  });
}

async function getStandings(league) {
  const data = await fetchJson(espnUrl(league, "scoreboard", { limit: 1 }, "v2"));
  const direct = data?.children?.flatMap(c => c?.standings?.entries || []) || [];
  if (direct.length) return direct.map(e => ({
    squadra: teamObject(e.team || {}),
    statistiche: (e.stats || []).map(normalizeStat)
  }));
  const site = await safeFetch(espnUrl(league, "standings"));
  if (site.success) {
    const entries = site.data?.children?.flatMap(c => c?.standings?.entries || []) || site.data?.standings?.entries || [];
    return entries.map(e => ({ squadra: teamObject(e.team || {}), statistiche: (e.stats || []).map(normalizeStat) }));
  }
  return [];
}

async function getTeams(league) {
  const data = await fetchJson(espnUrl(league, "teams"));
  const groups = data?.sports?.flatMap(s => s.leagues || []) || data?.leagues || [];
  const teams = groups.flatMap(l => l.teams || []).map(x => teamObject(x.team || x));
  return teams;
}

async function getComoTeam(league) {
  const teams = await getTeams(league);
  return teams.find(t => `${t.nome || ""} ${t.abbreviazione || ""}`.toLowerCase().includes("como")) || null;
}

async function getRoster(league, teamId) {
  if (!teamId) return { roster: [], errore: "ID squadra non disponibile: impossibile recuperare la rosa da questo endpoint." };
  const data = await fetchJson(espnUrl(league, `teams/${teamId}/roster`));
  const entries = data?.athletes || data?.roster || data?.team?.athletes || [];
  return {
    roster: entries.flatMap(group => Array.isArray(group?.items) ? group.items : [group]).filter(Boolean).map(a => ({
      id: a.id ?? null,
      nome: a.fullName ?? a.displayName ?? a.shortName ?? null,
      nome_breve: a.shortName ?? null,
      foto: a.headshot?.href ?? null,
      numero: a.jersey ?? null,
      ruolo: a.position?.displayName ?? a.position?.abbreviation ?? null,
      nazionalita: a.citizenship ?? a.birthPlace?.country ?? null,
      data_nascita: a.dateOfBirth ?? null,
      altezza: a.displayHeight ?? a.height ?? null,
      peso: a.displayWeight ?? a.weight ?? null
    }))
  };
}

async function getInjuries(league, teamId) {
  if (!teamId) return { indisponibili: [], errore: "ID squadra non disponibile." };
  const result = await safeFetch(espnUrl(league, `teams/${teamId}/injuries`));
  if (!result.success) return { indisponibili: [], errore: result.error };
  const items = result.data?.items || result.data?.injuries || [];
  return { indisponibili: items.map(x => ({
    giocatore: x.athlete?.displayName ?? x.athlete?.fullName ?? null,
    stato: x.status ?? x.type?.description ?? null,
    dettaglio: x.details?.detail ?? x.details?.type ?? null,
    data_rientro: x.details?.returnDate ?? null
  })) };
}

async function getSchedule(league, teamId) {
  if (!teamId) return { partite: [], errore: "ID squadra non disponibile." };
  const result = await safeFetch(espnUrl(league, `teams/${teamId}/schedule`));
  if (!result.success) return { partite: [], errore: result.error };
  const events = result.data?.events || result.data?.schedule || [];
  return { partite: events.map(normalizeEvent) };
}

async function getNews(teamName = "Como") {
  const result = await safeFetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/news`);
  if (!result.success) return { notizie: [], errore: result.error, nota: "Il feed ESPN potrebbe non coprire tutte le notizie sul Como." };
  const articles = result.data?.articles || [];
  const filtered = articles.filter(a => `${a.headline || ""} ${a.description || ""} ${a.categories?.map(c => c.description).join(" ") || ""}`.toLowerCase().includes(teamName.toLowerCase()));
  return { notizie: filtered.map(a => ({
    titolo: a.headline ?? null,
    descrizione: a.description ?? null,
    data_pubblicazione: a.published ?? null,
    url: a.links?.web?.href ?? null,
    immagine: a.images?.[0]?.url ?? null,
    fonte: "ESPN"
  })) };
}

async function getSummary(league, eventId) {
  return fetchJson(espnUrl(league, "summary", { event: eventId }));
}

async function getMatch(league, eventId) {
  const summary = await getSummary(league, eventId);
  const event = summary?.header?.competitions?.[0] ? normalizeEvent({
    id: summary.header.id || eventId,
    date: summary.header.competitions[0].date,
    name: summary.header.competitions[0].competitors?.map(x => x.team?.displayName).join(" - "),
    competitions: summary.header.competitions
  }) : null;
  return {
    partita: event,
    intestazione_originale: summary?.header ?? null,
    eventi: normalizePlays(summary),
    statistiche: normalizeBoxscore(summary),
    formazioni: normalizeLineups(summary),
    note: "I campi dipendono dalla copertura ESPN per questa partita.",
    dati_originali_espn: summary
  };
}

function apiList() {
  return {
    health: "/api/health",
    configurazione: "/api/configurazione",
    squadre: "/api/squadre?league=ita.1",
    como_team: "/api/como-team?league=ita.1",
    partite: "/api/partite?league=ita.1",
    classifica: "/api/classifica?league=ita.1",
    rosa: "/api/giocatori?league=ita.1",
    indisponibili: "/api/indisponibili?league=ita.1",
    notizie: "/api/notizie",
    partita_dettaglio: "/api/partita?id=ID_ESPN&league=ita.1",
    formazioni: "/api/formazioni?id=ID_ESPN&league=ita.1",
    coppe: "/api/coppe",
    scontri_diretti: "/api/scontri-diretti?team1=ID_ESPN&team2=ID_ESPN&league=ita.1"
  };
}

export default async function handler(req, res) {
  const rawPath = req.url?.split("?")[0] || "/";
  const route = rawPath.replace(/^\/api\/?/, "").replace(/\/$/, "") || "health";
  const q = req.query || {};
  const league = String(q.league || "ita.1");
  try {
    if (route === "health") {
      return json(res, 200, {
        success: true, progetto: "Il Pianeta Comasco API", versione: "2.0.0",
        stato: "online", ora_server: new Date().toISOString(), endpoints: apiList(),
        avviso: "I campi null o gli array vuoti indicano dati non forniti dalla fonte, non valori inventati."
      });
    }

    if (route === "configurazione") {
      return json(res, 200, {
        success: true,
        progetto: { nome: "Il Pianeta Comasco", versione: "2.0.0", sport: "Calcio" },
        squadre: [
          { nome: "Como", tipo: "prima squadra maschile", league_predefinita: "ita.1" },
          { nome: "Como Primavera", tipo: "primavera maschile", league_predefinita: null },
          { nome: "Como Women", tipo: "prima squadra femminile", league_predefinita: null }
        ],
        competizioni: LEAGUES,
        fonte_principale: "ESPN",
        fonti_notizie_previste: ["OneFootball", "Sky Sport", "La Gazzetta dello Sport", "Tuttomercatoweb"],
        endpoints: apiList(),
        limiti: [
          "Primavera e squadra femminile richiedono identificatori/competizioni ESPN effettivamente disponibili.",
          "Le probabili formazioni, squalifiche, assist, xG e alcune statistiche possono non essere disponibili per tutte le partite.",
          "Questo endpoint non dichiara fonti esterne come collegate se non sono implementate."
        ]
      });
    }

    if (route === "squadre") {
      const squadre = await getTeams(league);
      return json(res, 200, { success: true, fonte: "ESPN", league, totale: squadre.length, squadre });
    }

    if (route === "como-team") {
      const squadre = await getTeams(league);
      const como = squadre.find(t => `${t.nome || ""} ${t.abbreviazione || ""}`.toLowerCase().includes("como")) || null;
      return json(res, 200, { success: true, fonte: "ESPN", league, trovato: !!como, squadra: como, squadre_esaminate: squadre.length,
        nota: como ? null : "ESPN non ha restituito una squadra con nome Como per questa competizione." });
    }

    if (route === "partite") {
      const team = await getComoTeam(league);
      if (!team) return json(res, 200, { success: true, fonte: "ESPN", league, totale: 0, partite: [], avviso: "Squadra Como non trovata in questa lega ESPN. Prova /api/scoreboard?league=ita.1 per vedere gli eventi disponibili." });
      const data = await getSchedule(league, team.id);
      return json(res, 200, { success: true, fonte: "ESPN", league, squadra: team, totale: data.partite.length, ...data });
    }

    if (route === "scoreboard") {
      const dates = q.dates ? String(q.dates) : undefined;
      const partite = await getScoreboard(league, dates);
      return json(res, 200, { success: true, fonte: "ESPN", league, totale: partite.length, partite });
    }

    if (route === "classifica") {
      const classifica = await getStandings(league);
      return json(res, 200, { success: true, fonte: "ESPN", league, totale: classifica.length, classifica,
        avviso: classifica.length ? null : "ESPN non ha restituito la classifica per questa lega/endpoint." });
    }

    if (route === "giocatori") {
      const team = q.teamId ? { id: String(q.teamId), nome: null } : await getComoTeam(league);
      if (!team) return json(res, 200, { success: true, fonte: "ESPN", league, totale: 0, giocatori: [], errore_dati: "Squadra non trovata; consulta /api/squadre." });
      const data = await getRoster(league, team.id);
      return json(res, 200, { success: true, fonte: "ESPN", league, squadra: team, totale: data.roster.length, giocatori: data.roster, errore_dati: data.errore || null });
    }

    if (route === "indisponibili") {
      const team = q.teamId ? { id: String(q.teamId) } : await getComoTeam(league);
      if (!team) return json(res, 200, { success: true, fonte: "ESPN", league, indisponibili: [], errore_dati: "Squadra non trovata; consulta /api/squadre." });
      return json(res, 200, { success: true, fonte: "ESPN", league, squadra: team, ...(await getInjuries(league, team.id)) });
    }

    if (route === "notizie") {
      return json(res, 200, { success: true, fonte: "ESPN", ...(await getNews(String(q.term || "Como"))) });
    }

    if (route === "partita" || route === "formazioni") {
      const id = String(q.id || q.event || "");
      if (!id) return json(res, 400, { success: false, errore: "Parametro obbligatorio mancante: ?id=ID_ESPN", esempio: "/api/partita?id=123456&league=ita.1" });
      const match = await getMatch(league, id);
      if (route === "formazioni") return json(res, 200, { success: true, fonte: "ESPN", league, id, partita: match.partita, formazioni: match.formazioni, dati_originali_espn: match.dati_originali_espn });
      return json(res, 200, { success: true, fonte: "ESPN", league, ...match });
    }

    if (route === "coppe") {
      const results = {};
      for (const [key, competition] of Object.entries(LEAGUES)) {
        const response = await safeFetch(espnUrl(competition, "scoreboard"));
        results[key] = response.success
          ? { league: competition, totale_eventi: getEvents(response.data).length, eventi: getEvents(response.data).map(normalizeEvent).filter(findComo) }
          : { league: competition, totale_eventi: 0, eventi: [], errore: response.error };
      }
      return json(res, 200, { success: true, fonte: "ESPN", competizioni: results });
    }

    if (route === "scontri-diretti") {
      const team1 = String(q.team1 || "");
      const team2 = String(q.team2 || "");
      if (!team1 || !team2) return json(res, 400, { success: false, errore: "Servono team1 e team2 come ID ESPN; prima consulta /api/squadre." });
      const [a, b] = await Promise.all([
        safeFetch(espnUrl(league, `teams/${team1}/schedule`)),
        safeFetch(espnUrl(league, `teams/${team2}/schedule`))
      ]);
      if (!a.success || !b.success) return json(res, 200, { success: true, fonte: "ESPN", scontri_diretti: [], errori: [a.error, b.error].filter(Boolean) });
      const eventsA = a.data?.events || a.data?.schedule || [];
      const eventsB = b.data?.events || b.data?.schedule || [];
      const idsB = new Set(eventsB.map(e => String(e.id)));
      const common = eventsA.filter(e => idsB.has(String(e.id))).map(normalizeEvent).sort((x,y) => String(y.data_ora_utc).localeCompare(String(x.data_ora_utc)));
      return json(res, 200, { success: true, fonte: "ESPN", totale: common.length, scontri_diretti: common });
    }

    return json(res, 404, { success: false, errore: "Endpoint non trovato", route, endpoints: apiList() });
  } catch (error) {
    console.error("Il Pianeta Comasco API:", error);
    return json(res, 502, {
      success: false,
      errore: error?.message || "Errore sconosciuto",
      route,
      league,
      suggerimento: "Apri /api/health e poi /api/squadre?league=ita.1. Se la fonte ESPN non risponde o non supporta l'endpoint, l'errore viene mostrato qui invece di riempire i campi con valori inventati."
    });
  }
}
